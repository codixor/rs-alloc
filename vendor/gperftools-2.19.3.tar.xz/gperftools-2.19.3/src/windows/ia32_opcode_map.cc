// -*- Mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
/* Copyright (c) 2007, Google Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ---
 * Author: Joi Sigurdsson
 *
 * Opcode decoding maps.  Based on the IA-32 Intel® Architecture
 * Software Developer's Manual Volume 2: Instruction Set Reference.  Idea
 * for how to lay out the tables in memory taken from the implementation
 * in the Bastard disassembly environment.
 */

#include "mini_disassembler.h"

namespace sidestep {

/*
 * This is the first table to be searched; the first field of each
 * Opcode in the table is either 0 to indicate you're in the
 * right table, or an index to the correct table, in the global
 * map g_pentiumOpcodeMap
 */
const Opcode s_first_opcode_byte[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x8 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xD */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xE */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xF */
    {1, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x10 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x11 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x12 */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x13 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x14 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x15 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x16 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x17 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x18 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x19 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1A */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1C */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x1D */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x1E */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x1F */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x20 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x21 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x22 */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x23 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x24 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x25 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x26 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x27 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "daa", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x28 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x29 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2A */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2C */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2D */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2E */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2F */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "das", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x30 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x31 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x32 */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x33 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x34 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x35 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x36 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x37 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "aaa", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x38 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x39 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3A */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3C */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3D */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3E */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3F */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "aas", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
#ifdef _M_X64
    /* REX Prefixes in 64-bit mode. */
    /* 0x40 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x41 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x42 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x43 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x44 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x45 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x46 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x47 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x48 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x49 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4A */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4B */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4C */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4D */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4E */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4F */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
#else
    /* 0x40 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x41 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x42 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x43 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x44 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x45 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x46 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x47 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x48 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x49 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4A */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4B */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4C */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4D */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4E */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4F */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
#endif
    /* 0x50 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x51 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x52 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x53 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x54 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x55 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x56 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x57 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x58 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x59 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5A */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5B */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5C */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5D */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5E */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5F */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x60 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "pushad", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x61 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "popad", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x62 */
    {0, IT_GENERIC, AM_G | OT_V, AM_M | OT_A, AM_NOT_USED, "bound", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x63 */
    {0, IT_GENERIC, AM_E | OT_W, AM_G | OT_W, AM_NOT_USED, "arpl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x64 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x65 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x66 */
    {0, IT_PREFIX_OPERAND, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x67 */
    {0, IT_PREFIX_ADDRESS, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x68 */
    {0, IT_GENERIC, AM_I | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x69 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_I | OT_V, "imul", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6A */
    {0, IT_GENERIC, AM_I | OT_B, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_I | OT_B, "imul", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6C */
    {0, IT_GENERIC, AM_Y | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "insb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6D */
    {0, IT_GENERIC, AM_Y | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "insd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6E */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_X | OT_B, AM_NOT_USED, "outsb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6F */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_X | OT_V, AM_NOT_USED, "outsb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x70 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x71 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jno", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x72 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x73 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jnc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x74 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x75 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jnz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x76 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jbe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x77 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "ja", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x78 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "js", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x79 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jns", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7A */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jpe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7B */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jpo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7C */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7D */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jge", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7E */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jle", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7F */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x80 */
    {2, IT_REFERENCE, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x81 */
    {3, IT_REFERENCE, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x82 */
    {4, IT_REFERENCE, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x83 */
    {5, IT_REFERENCE, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x84 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x85 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x86 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x87 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x88 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x89 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8A */
    {0, IT_GENERIC, AM_G | OT_B, AM_E | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8C */
    {0, IT_GENERIC, AM_E | OT_W, AM_S | OT_W, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8D */
    {0, IT_GENERIC, AM_G | OT_V, AM_M | OT_ADDRESS_MODE_M, AM_NOT_USED, "lea", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x8E */
    {0, IT_GENERIC, AM_S | OT_W, AM_E | OT_W, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8F */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x90 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "nop", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x91 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x92 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x93 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x94 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x95 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x96 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x97 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "xchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x98 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cwde", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x99 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cdq", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9A */
    {0, IT_JUMP, AM_A | OT_P, AM_NOT_USED, AM_NOT_USED, "callf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9B */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "wait", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9C */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "pushfd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x9D */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "popfd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9E */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "sahf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9F */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "lahf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA0 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_O | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA1 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_O | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA2 */
    {0, IT_GENERIC, AM_O | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA3 */
    {0, IT_GENERIC, AM_O | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA4 */
    {0, IT_GENERIC, AM_X | OT_B, AM_Y | OT_B, AM_NOT_USED, "movsb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA5 */
    {0, IT_GENERIC, AM_X | OT_V, AM_Y | OT_V, AM_NOT_USED, "movsd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA6 */
    {0, IT_GENERIC, AM_X | OT_B, AM_Y | OT_B, AM_NOT_USED, "cmpsb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA7 */
    {0, IT_GENERIC, AM_X | OT_V, AM_Y | OT_V, AM_NOT_USED, "cmpsd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA8 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA9 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAA */
    {0, IT_GENERIC, AM_Y | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "stosb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAB */
    {0, IT_GENERIC, AM_Y | OT_V, AM_REGISTER | OT_V, AM_NOT_USED, "stosd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAC */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_X | OT_B, AM_NOT_USED, "lodsb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAD */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_X | OT_V, AM_NOT_USED, "lodsd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAE */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_Y | OT_B, AM_NOT_USED, "scasb", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAF */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_Y | OT_V, AM_NOT_USED, "scasd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB0 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB1 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB2 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB3 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB4 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB5 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB6 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB7 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
#ifdef _M_X64
    /* 0xB8 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB9 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBA */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBB */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBC */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBD */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBE */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBF */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V | IOS_64, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
#else
    /* 0xB8 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB9 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBA */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBB */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBC */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBD */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBE */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xBF */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
#endif
    /* 0xC0 */
    {6, IT_REFERENCE, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC1 */
    {7, IT_REFERENCE, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC2 */
    {0, IT_RETURN, AM_I | OT_W, AM_NOT_USED, AM_NOT_USED, "ret", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC3 */
    {0, IT_RETURN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "ret", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC4 */
    {0, IT_GENERIC, AM_G | OT_V, AM_M | OT_P, AM_NOT_USED, "les", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC5 */
    {0, IT_GENERIC, AM_G | OT_V, AM_M | OT_P, AM_NOT_USED, "lds", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC6 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC8 */
    {0, IT_GENERIC, AM_I | OT_W, AM_I | OT_B, AM_NOT_USED, "enter", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC9 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "leave", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCA */
    {0, IT_RETURN, AM_I | OT_W, AM_NOT_USED, AM_NOT_USED, "retf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCB */
    {0, IT_RETURN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "retf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCC */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "int3", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCD */
    {0, IT_GENERIC, AM_I | OT_B, AM_NOT_USED, AM_NOT_USED, "int", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCE */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "into", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xCF */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "iret", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD0 */
    {8, IT_REFERENCE, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD1 */
    {9, IT_REFERENCE, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD2 */
    {10, IT_REFERENCE, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD3 */
    {11, IT_REFERENCE, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD4 */
    {0, IT_GENERIC, AM_I | OT_B, AM_NOT_USED, AM_NOT_USED, "aam", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD5 */
    {0, IT_GENERIC, AM_I | OT_B, AM_NOT_USED, AM_NOT_USED, "aad", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD6 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD7 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "xlat", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},

    // The following 8 lines would be references to the FPU tables, but we currently
    // do not support the FPU instructions in this disassembler.

    /* 0xD8 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD9 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDA */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDB */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDC */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDD */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDE */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xDF */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},

    /* 0xE0 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "loopnz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE1 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "loopz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE2 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "loop", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE3 */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jcxz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE4 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "in", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xE5 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_I | OT_B, AM_NOT_USED, "in", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xE6 */
    {0, IT_GENERIC, AM_I | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "out", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xE7 */
    {0, IT_GENERIC, AM_I | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "out", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xE8 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "call", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE9 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xEA */
    {0, IT_JUMP, AM_A | OT_P, AM_NOT_USED, AM_NOT_USED, "jmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xEB */
    {0, IT_JUMP, AM_J | OT_B, AM_NOT_USED, AM_NOT_USED, "jmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xEC */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_REGISTER | OT_W, AM_NOT_USED, "in", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xED */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_REGISTER | OT_W, AM_NOT_USED, "in", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xEE */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_REGISTER | OT_B, AM_NOT_USED, "out", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xEF */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_REGISTER | OT_V, AM_NOT_USED, "out", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xF0 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "lock:", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF1 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF2 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "repne:", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF3 */
    {0, IT_PREFIX, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "rep:", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF4 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "hlt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF5 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cmc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF6 */
    {12, IT_REFERENCE, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF7 */
    {13, IT_REFERENCE, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF8 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "clc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF9 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "stc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFA */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cli", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFB */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "sti", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFC */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cld", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFD */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "std", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFE */
    {14, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xFF */
    {15, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f[] = {
    /* 0x0 */ {16, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {17, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_W, AM_NOT_USED, "lar", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_W, AM_NOT_USED, "lsl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "clts", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "invd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "wbinvd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "ud2", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xE */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x10 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "movups", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "movsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "movss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "movupd"}},
    /* 0x11 */
    {0, IT_GENERIC, AM_W | OT_PS, AM_V | OT_PS, AM_NOT_USED, "movups", true,
     /* F2h */ {0, IT_GENERIC, AM_W | OT_SD, AM_V | OT_SD, AM_NOT_USED, "movsd"},
     /* F3h */ {0, IT_GENERIC, AM_W | OT_SS, AM_V | OT_SS, AM_NOT_USED, "movss"},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_PD, AM_V | OT_PD, AM_NOT_USED, "movupd"}},
    /* 0x12 */
    {0, IT_GENERIC, AM_W | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movlps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movhlps"},  // only one of ...
     /* F3h */ {0, IT_GENERIC, AM_V | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movhlps"},  // ...these two is correct, Intel
                                                                                   // doesn't specify which
     /* 66h */ {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_S, AM_NOT_USED, "movlpd"}},
    /* 0x13 */
    {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movlps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movlpd"}},
    /* 0x14 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_Q, AM_NOT_USED, "unpcklps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_Q, AM_NOT_USED, "unpcklpd"}},
    /* 0x15 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_Q, AM_NOT_USED, "unpckhps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_Q, AM_NOT_USED, "unpckhpd"}},
    /* 0x16 */
    {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movhps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movlhps"},  // only one of...
     /* F3h */ {0, IT_GENERIC, AM_V | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movlhps"},  // ...these two is correct, Intel
                                                                                   // doesn't specify which
     /* 66h */ {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movhpd"}},
    /* 0x17 */
    {0, IT_GENERIC, AM_W | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movhps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movhpd"}},
    /* 0x18 */
    {18, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x19 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1A */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1B */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1C */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1D */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1E */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1F */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x20 */
    {0, IT_GENERIC, AM_R | OT_D, AM_C | OT_D, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x21 */
    {0, IT_GENERIC, AM_R | OT_D, AM_D | OT_D, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x22 */
    {0, IT_GENERIC, AM_C | OT_D, AM_R | OT_D, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x23 */
    {0, IT_GENERIC, AM_D | OT_D, AM_R | OT_D, AM_NOT_USED, "mov", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x24 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x25 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x26 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x27 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x28 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "movaps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "movapd"}},
    /* 0x29 */
    {0, IT_GENERIC, AM_W | OT_PS, AM_V | OT_PS, AM_NOT_USED, "movaps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_PD, AM_V | OT_PD, AM_NOT_USED, "movapd"}},
    /* 0x2A */
    {0, IT_GENERIC, AM_V | OT_PS, AM_Q | OT_Q, AM_NOT_USED, "cvtpi2ps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_E | OT_D, AM_NOT_USED, "cvtsi2sd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_E | OT_D, AM_NOT_USED, "cvtsi2ss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_Q | OT_DQ, AM_NOT_USED, "cvtpi2pd"}},
    /* 0x2B */
    {0, IT_GENERIC, AM_W | OT_PS, AM_V | OT_PS, AM_NOT_USED, "movntps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_PD, AM_V | OT_PD, AM_NOT_USED, "movntpd"}},
    /* 0x2C */
    {0, IT_GENERIC, AM_Q | OT_Q, AM_W | OT_PS, AM_NOT_USED, "cvttps2pi", true,
     /* F2h */ {0, IT_GENERIC, AM_G | OT_D, AM_W | OT_SD, AM_NOT_USED, "cvttsd2si"},
     /* F3h */ {0, IT_GENERIC, AM_G | OT_D, AM_W | OT_SS, AM_NOT_USED, "cvttss2si"},
     /* 66h */ {0, IT_GENERIC, AM_Q | OT_DQ, AM_W | OT_PD, AM_NOT_USED, "cvttpd2pi"}},
    /* 0x2D */
    {0, IT_GENERIC, AM_Q | OT_Q, AM_W | OT_PS, AM_NOT_USED, "cvtps2pi", true,
     /* F2h */ {0, IT_GENERIC, AM_G | OT_D, AM_W | OT_SD, AM_NOT_USED, "cvtsd2si"},
     /* F3h */ {0, IT_GENERIC, AM_G | OT_D, AM_W | OT_SS, AM_NOT_USED, "cvtss2si"},
     /* 66h */ {0, IT_GENERIC, AM_Q | OT_DQ, AM_W | OT_PD, AM_NOT_USED, "cvtpd2pi"}},
    /* 0x2E */
    {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "ucomiss", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "ucomisd"}},
    /* 0x2F */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_SS, AM_NOT_USED, "comiss", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "comisd"}},
    /* 0x30 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "wrmsr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x31 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "rdtsc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x32 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "rdmsr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x33 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "rdpmc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x34 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "sysenter", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x35 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "sysexit", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x36 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x37 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x38 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x39 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3A */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3B */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3C */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "movnti", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3D */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3E */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3F */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x40 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x41 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovno", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x42 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x43 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovnc", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x44 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x45 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovnz", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x46 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovbe", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x47 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmova", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x48 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovs", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x49 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovns", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4A */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovpe", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4B */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovpo", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4C */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4D */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovge", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4E */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovle", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4F */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "cmovg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x50 */
    {0, IT_GENERIC, AM_E | OT_D, AM_V | OT_PS, AM_NOT_USED, "movmskps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_E | OT_D, AM_V | OT_PD, AM_NOT_USED, "movmskpd"}},
    /* 0x51 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "sqrtps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "sqrtsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "sqrtss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "sqrtpd"}},
    /* 0x52 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "rsqrtps", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "rsqrtss"},
     /* 66h */ {0}},
    /* 0x53 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "rcpps", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "rcpss"},
     /* 66h */ {0}},
    /* 0x54 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "andps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "andpd"}},
    /* 0x55 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "andnps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "andnpd"}},
    /* 0x56 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "orps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "orpd"}},
    /* 0x57 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "xorps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "xorpd"}},
    /* 0x58 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "addps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "addsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "addss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "addpd"}},
    /* 0x59 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "mulps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "mulsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "mulss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "mulpd"}},
    /* 0x5A */
    {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PS, AM_NOT_USED, "cvtps2pd", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "cvtsd2ss"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "cvtss2sd"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PD, AM_NOT_USED, "cvtpd2ps"}},
    /* 0x5B */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_DQ, AM_NOT_USED, "cvtdq2ps", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_PS, AM_NOT_USED, "cvttps2dq"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_PS, AM_NOT_USED, "cvtps2dq"}},
    /* 0x5C */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "subps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "subsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "subss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "subpd"}},
    /* 0x5D */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "minps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "minsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "minss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "minpd"}},
    /* 0x5E */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "divps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "divsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "divss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "divpd"}},
    /* 0x5F */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_NOT_USED, "maxps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_NOT_USED, "maxsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_NOT_USED, "maxss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_NOT_USED, "maxpd"}},
    /* 0x60 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpcklbw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "punpcklbw"}},
    /* 0x61 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpcklwd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "punpcklwd"}},
    /* 0x62 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpckldq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "punpckldq"}},
    /* 0x63 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "packsswb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "packsswb"}},
    /* 0x64 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "pcmpgtb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpgtb"}},
    /* 0x65 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "pcmpgtw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpgtw"}},
    /* 0x66 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "pcmpgtd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpgtd"}},
    /* 0x67 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "packuswb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "packuswb"}},
    /* 0x68 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpckhbw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_Q | OT_DQ, AM_NOT_USED, "punpckhbw"}},
    /* 0x69 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpckhwd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_Q | OT_DQ, AM_NOT_USED, "punpckhwd"}},
    /* 0x6A */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "punpckhdq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_Q | OT_DQ, AM_NOT_USED, "punpckhdq"}},
    /* 0x6B */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "packssdw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_Q | OT_DQ, AM_NOT_USED, "packssdw"}},
    /* 0x6C */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "not used without prefix", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "punpcklqdq"}},
    /* 0x6D */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "not used without prefix", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "punpcklqdq"}},
    /* 0x6E */
    {0, IT_GENERIC, AM_P | OT_D, AM_E | OT_D, AM_NOT_USED, "movd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_E | OT_D, AM_NOT_USED, "movd"}},
    /* 0x6F */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_D, AM_NOT_USED, "movq", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "movdqu"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "movdqa"}},
    /* 0x70 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_I | OT_B, "pshuf", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_I | OT_B, "pshuflw"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_I | OT_B, "pshufhw"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_I | OT_B, "pshufd"}},
    /* 0x71 */
    {19, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x72 */
    {20, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x73 */
    {21, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x74 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pcmpeqb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpeqb"}},
    /* 0x75 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pcmpeqw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpeqw"}},
    /* 0x76 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pcmpeqd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pcmpeqd"}},
    /* 0x77 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "emms", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},

    // The following six opcodes are escapes into the MMX stuff, which this disassembler does not support.
    /* 0x78 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x79 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7A */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7B */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7C */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7D */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},

    /* 0x7E */
    {0, IT_GENERIC, AM_E | OT_D, AM_P | OT_D, AM_NOT_USED, "movd", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movq"},
     /* 66h */ {0, IT_GENERIC, AM_E | OT_D, AM_V | OT_DQ, AM_NOT_USED, "movd"}},
    /* 0x7F */
    {0, IT_GENERIC, AM_Q | OT_Q, AM_P | OT_Q, AM_NOT_USED, "movq", true,
     /* F2h */ {0},
     /* F3h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_V | OT_DQ, AM_NOT_USED, "movdqu"},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_V | OT_DQ, AM_NOT_USED, "movdqa"}},
    /* 0x80 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x81 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jno", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x82 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x83 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jnc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x84 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x85 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jnz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x86 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jbe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x87 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "ja", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x88 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "js", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x89 */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jns", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8A */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jpe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8B */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jpo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8C */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8D */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jge", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8E */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jle", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x8F */
    {0, IT_JUMP, AM_J | OT_V, AM_NOT_USED, AM_NOT_USED, "jg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x90 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "seto", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x91 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setno", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x92 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x93 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setnc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x94 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x95 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setnz", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x96 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setbe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x97 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "seta", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x98 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "sets", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x99 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setns", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9A */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setpe", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9B */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setpo", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9C */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9D */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setge", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9E */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setle", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x9F */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "setg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA0 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA1 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA2 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "cpuid", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "bt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_I | OT_B, "shld", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_I | OT_B | AM_REGISTER, "shld", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA6 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA7 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xA8 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xA9 */
    {0, IT_GENERIC, AM_REGISTER | OT_W, AM_NOT_USED, AM_NOT_USED, "pop", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAA */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "rsm", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xAB */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "bts", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xAC */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_I | OT_B, "shrd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xAD */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_I | OT_B | AM_REGISTER, "shrd", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xAE */
    {22, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xAF */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "imul", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB0 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "cmpxchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "cmpxchg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xB2 */
    {0, IT_GENERIC, AM_M | OT_P, AM_NOT_USED, AM_NOT_USED, "lss", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "btr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB4 */
    {0, IT_GENERIC, AM_M | OT_P, AM_NOT_USED, AM_NOT_USED, "lfs", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB5 */
    {0, IT_GENERIC, AM_M | OT_P, AM_NOT_USED, AM_NOT_USED, "lgs", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB6 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_B, AM_NOT_USED, "movzx", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB7 */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_W, AM_NOT_USED, "movzx", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB8 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xB9 */
    {0, IT_UNKNOWN, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "ud1", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBA */
    {23, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBB */
    {0, IT_GENERIC, AM_E | OT_V, AM_G | OT_V, AM_NOT_USED, "btc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBC */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "bsf", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBD */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_V, AM_NOT_USED, "bsr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBE */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_B, AM_NOT_USED, "movsx", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xBF */
    {0, IT_GENERIC, AM_G | OT_V, AM_E | OT_W, AM_NOT_USED, "movsx", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC0 */
    {0, IT_GENERIC, AM_E | OT_B, AM_G | OT_B, AM_NOT_USED, "xadd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "xadd", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC2 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_I | OT_B, "cmpps", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_SD, AM_W | OT_SD, AM_I | OT_B, "cmpsd"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_SS, AM_W | OT_SS, AM_I | OT_B, "cmpss"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_I | OT_B, "cmppd"}},
    /* 0xC3 */
    {0, IT_GENERIC, AM_E | OT_D, AM_G | OT_D, AM_NOT_USED, "movnti", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xC4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_E | OT_D, AM_I | OT_B, "pinsrw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_E | OT_D, AM_I | OT_B, "pinsrw"}},
    /* 0xC5 */
    {0, IT_GENERIC, AM_G | OT_D, AM_P | OT_Q, AM_I | OT_B, "pextrw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_G | OT_D, AM_V | OT_DQ, AM_I | OT_B, "pextrw"}},
    /* 0xC6 */
    {0, IT_GENERIC, AM_V | OT_PS, AM_W | OT_PS, AM_I | OT_B, "shufps", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_PD, AM_I | OT_B, "shufpd"}},
    /* 0xC7 */
    {24, IT_REFERENCE, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xC8 */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xC9 */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCA */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCB */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCC */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCD */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCE */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xCF */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "bswap", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0xD0 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xD1 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psrlw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psrlw"}},
    /* 0xD2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psrld", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psrld"}},
    /* 0xD3 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psrlq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psrlq"}},
    /* 0xD4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddq"}},
    /* 0xD5 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmullw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmullw"}},
    /* 0xD6 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "unused without prefix", true,
     /* F2h */ {0, IT_GENERIC, AM_P | OT_Q, AM_W | OT_Q, AM_NOT_USED, "movdq2q"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_Q | OT_Q, AM_NOT_USED, "movq2dq"},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movq"}},
    /* 0xD7 */
    {0, IT_GENERIC, AM_G | OT_D, AM_P | OT_Q, AM_NOT_USED, "pmovmskb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_G | OT_D, AM_V | OT_DQ, AM_NOT_USED, "pmovmskb"}},
    /* 0xD8 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubusb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubusb"}},
    /* 0xD9 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubusw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubusw"}},
    /* 0xDA */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pminub", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pminub"}},
    /* 0xDB */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pand", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pand"}},
    /* 0xDC */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddusb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddusb"}},
    /* 0xDD */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddusw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddusw"}},
    /* 0xDE */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmaxub", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmaxub"}},
    /* 0xDF */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pandn", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pandn"}},
    /* 0xE0 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pavgb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pavgb"}},
    /* 0xE1 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psraw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psrqw"}},
    /* 0xE2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psrad", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psrad"}},
    /* 0xE3 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pavgw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pavgw"}},
    /* 0xE4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmulhuw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmulhuw"}},
    /* 0xE5 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmulhuw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmulhw"}},
    /* 0xE6 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "not used without prefix", true,
     /* F2h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_PD, AM_NOT_USED, "cvtpd2dq"},
     /* F3h */ {0, IT_GENERIC, AM_V | OT_PD, AM_W | OT_DQ, AM_NOT_USED, "cvtdq2pd"},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_PD, AM_NOT_USED, "cvttpd2dq"}},
    /* 0xE7 */
    {0, IT_GENERIC, AM_W | OT_Q, AM_V | OT_Q, AM_NOT_USED, "movntq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_V | OT_DQ, AM_NOT_USED, "movntdq"}},
    /* 0xE8 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubsb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubsb"}},
    /* 0xE9 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubsw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubsw"}},
    /* 0xEA */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pminsw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pminsw"}},
    /* 0xEB */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "por", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "por"}},
    /* 0xEC */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddsb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddsb"}},
    /* 0xED */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddsw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddsw"}},
    /* 0xEE */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmaxsw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmaxsw"}},
    /* 0xEF */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pxor", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pxor"}},
    /* 0xF0 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0xF1 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psllw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psllw"}},
    /* 0xF2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pslld", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pslld"}},
    /* 0xF3 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psllq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psllq"}},
    /* 0xF4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmuludq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmuludq"}},
    /* 0xF5 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "pmaddwd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "pmaddwd"}},
    /* 0xF6 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psadbw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psadbw"}},
    /* 0xF7 */
    {0, IT_GENERIC, AM_P | OT_PI, AM_Q | OT_PI, AM_NOT_USED, "maskmovq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "maskmovdqu"}},
    /* 0xF8 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubb"}},
    /* 0xF9 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubw"}},
    /* 0xFA */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubd"}},
    /* 0xFB */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "psubq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "psubq"}},
    /* 0xFC */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddb", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddb"}},
    /* 0xFD */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddw"}},
    /* 0xFE */
    {0, IT_GENERIC, AM_P | OT_Q, AM_Q | OT_Q, AM_NOT_USED, "paddd", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_V | OT_DQ, AM_W | OT_DQ, AM_NOT_USED, "paddd"}},
    /* 0xFF */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f00[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "sldt", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "str", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "lldt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "ltr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "verr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "verw", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f01[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_M | OT_S, AM_NOT_USED, AM_NOT_USED, "sgdt", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_M | OT_S, AM_NOT_USED, AM_NOT_USED, "sidt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_M | OT_S, AM_NOT_USED, AM_NOT_USED, "lgdt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_M | OT_S, AM_NOT_USED, AM_NOT_USED, "lidt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "smsw", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_W, AM_NOT_USED, AM_NOT_USED, "lmsw", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_M | OT_B, AM_NOT_USED, AM_NOT_USED, "invlpg", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f18[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_M | OT_ADDRESS_MODE_M, AM_NOT_USED, AM_NOT_USED, "prefetch", false, /* F2h */ {0},
               /* F3h */ {0}, /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "prefetch", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "prefetch", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_REGISTER | OT_D, AM_NOT_USED, AM_NOT_USED, "prefetch", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f71[] = {
    /* 0x0 */ {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psrlw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psrlw"}},
    /* 0x3 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psraw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psraw"}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psllw", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_P | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psllw"}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f72[] = {
    /* 0x0 */ {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psrld", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psrld"}},
    /* 0x3 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psrad", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psrad"}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "pslld", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "pslld"}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0f73[] = {
    /* 0x0 */ {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psrlq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psrlq"}},
    /* 0x3 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_P | OT_Q, AM_I | OT_B, AM_NOT_USED, "psllq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "psllq"}},
    /* 0x7 */
    {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "pslldq", true,
     /* F2h */ {0},
     /* F3h */ {0},
     /* 66h */ {0, IT_GENERIC, AM_W | OT_DQ, AM_I | OT_B, AM_NOT_USED, "pslldq"}},
};

const Opcode s_opcode_byte_after_0fae[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "fxsave", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "fxrstor", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "ldmxcsr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "stmxcsr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "lfence", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "mfence", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, "clflush/sfence", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
};

const Opcode s_opcode_byte_after_0fba[] = {
    /* 0x0 */ {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "bt", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "bts", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "btr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "btc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_0fc7[] = {
    /* 0x0 */ {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */ {0, IT_GENERIC, AM_M | OT_Q, AM_NOT_USED, AM_NOT_USED, "cmpxch8b", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}}};

const Opcode s_opcode_byte_after_80[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_81[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_82[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_83[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "add", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "or", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "adc", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sbb", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "and", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sub", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "xor", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "cmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_c0[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_c1[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_B, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_d0[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_B, AM_IMPLICIT, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_d1[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_IMPLICIT, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

const Opcode s_opcode_byte_after_d2[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_B, AM_REGISTER | OT_B, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}}};

const Opcode s_opcode_byte_after_d3[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "rol", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "ror", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "rcl", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "rcr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "shl", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "shr", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "sal", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_E | OT_V, AM_REGISTER | OT_B, AM_NOT_USED, "sar", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}}};

const Opcode s_opcode_byte_after_f6[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_B, AM_I | OT_B, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "not", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "neg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, OT_B | AM_REGISTER, AM_E | OT_B, AM_NOT_USED, "mul", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, OT_B | AM_REGISTER, AM_E | OT_B, AM_NOT_USED, "imul", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_E | OT_B, AM_NOT_USED, "div", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_REGISTER | OT_B, AM_E | OT_B, AM_NOT_USED, "idiv", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}}};

const Opcode s_opcode_byte_after_f7[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_I | OT_V, AM_NOT_USED, "test", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "not", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "neg", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_E | OT_V, AM_NOT_USED, "mul", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x5 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_E | OT_V, AM_NOT_USED, "imul", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_E | OT_V, AM_NOT_USED, "div", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}},
    /* 0x7 */
    {0, IT_GENERIC, AM_REGISTER | OT_V, AM_E | OT_V, AM_NOT_USED, "idiv", false, /* F2h */ {0}, /* F3h */ {0},
     /* 66h */ {0}}};

const Opcode s_opcode_byte_after_fe[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */ {0, IT_GENERIC, AM_E | OT_B, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}}};

const Opcode s_opcode_byte_after_ff[] = {
    /* 0x0 */ {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "inc", false, /* F2h */ {0}, /* F3h */ {0},
               /* 66h */ {0}},
    /* 0x1 */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "dec", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x2 */
    {0, IT_JUMP, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "call", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x3 */
    {0, IT_JUMP, AM_E | OT_P, AM_NOT_USED, AM_NOT_USED, "call", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x4 */
    {0, IT_JUMP, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "jmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x5 */
    {0, IT_JUMP, AM_E | OT_P, AM_NOT_USED, AM_NOT_USED, "jmp", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x6 */
    {0, IT_GENERIC, AM_E | OT_V, AM_NOT_USED, AM_NOT_USED, "push", false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}},
    /* 0x7 */
    {0, IT_UNUSED, AM_NOT_USED, AM_NOT_USED, AM_NOT_USED, 0, false, /* F2h */ {0}, /* F3h */ {0}, /* 66h */ {0}}};

/*
 * A table of all the other tables, containing some extra information, e.g.
 * how to mask out the byte we're looking at.
 */
const OpcodeTable MiniDisassembler::s_ia32_opcode_map_[] = {
    // One-byte opcodes and jumps to larger
    /*  0 */ {s_first_opcode_byte, 0, 0xff, 0, 0xff},
    // Two-byte opcodes (second byte)
    /*  1 */ {s_opcode_byte_after_0f, 0, 0xff, 0, 0xff},
    // Start of tables for opcodes using ModR/M bits as extension
    /*  2 */ {s_opcode_byte_after_80, 3, 0x07, 0, 0x07},
    /*  3 */ {s_opcode_byte_after_81, 3, 0x07, 0, 0x07},
    /*  4 */ {s_opcode_byte_after_82, 3, 0x07, 0, 0x07},
    /*  5 */ {s_opcode_byte_after_83, 3, 0x07, 0, 0x07},
    /*  6 */ {s_opcode_byte_after_c0, 3, 0x07, 0, 0x07},
    /*  7 */ {s_opcode_byte_after_c1, 3, 0x07, 0, 0x07},
    /*  8 */ {s_opcode_byte_after_d0, 3, 0x07, 0, 0x07},
    /*  9 */ {s_opcode_byte_after_d1, 3, 0x07, 0, 0x07},
    /* 10 */ {s_opcode_byte_after_d2, 3, 0x07, 0, 0x07},
    /* 11 */ {s_opcode_byte_after_d3, 3, 0x07, 0, 0x07},
    /* 12 */ {s_opcode_byte_after_f6, 3, 0x07, 0, 0x07},
    /* 13 */ {s_opcode_byte_after_f7, 3, 0x07, 0, 0x07},
    /* 14 */ {s_opcode_byte_after_fe, 3, 0x07, 0, 0x01},
    /* 15 */ {s_opcode_byte_after_ff, 3, 0x07, 0, 0x07},
    /* 16 */ {s_opcode_byte_after_0f00, 3, 0x07, 0, 0x07},
    /* 17 */ {s_opcode_byte_after_0f01, 3, 0x07, 0, 0x07},
    /* 18 */ {s_opcode_byte_after_0f18, 3, 0x07, 0, 0x07},
    /* 19 */ {s_opcode_byte_after_0f71, 3, 0x07, 0, 0x07},
    /* 20 */ {s_opcode_byte_after_0f72, 3, 0x07, 0, 0x07},
    /* 21 */ {s_opcode_byte_after_0f73, 3, 0x07, 0, 0x07},
    /* 22 */ {s_opcode_byte_after_0fae, 3, 0x07, 0, 0x07},
    /* 23 */ {s_opcode_byte_after_0fba, 3, 0x07, 0, 0x07},
    /* 24 */ {s_opcode_byte_after_0fc7, 3, 0x07, 0, 0x01}};

};  // namespace sidestep
